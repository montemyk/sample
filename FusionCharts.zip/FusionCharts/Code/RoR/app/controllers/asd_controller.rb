class AsdController < ApplicationController
end
