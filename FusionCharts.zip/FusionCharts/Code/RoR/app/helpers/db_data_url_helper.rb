module DbDataUrlHelper
end
